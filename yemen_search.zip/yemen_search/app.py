import os, re, json, sqlite3
from flask import Flask, render_template, request, g, abort, jsonify
from markupsafe import Markup, escape
from arabic import norm, key, norm_with_map
import build_index
from build_index import SOURCES

BASE = os.path.dirname(os.path.abspath(__file__))
UDB = os.path.join(BASE, 'data', 'unified.db')
if not os.path.exists(UDB):
    build_index.build()

app = Flask(__name__)
app.jinja_env.filters['nl2br'] = lambda s: Markup('<br>').join(escape(x) for x in (s or '').split('\n'))

TYPE_LABEL = {'place': 'موضع/بلد', 'tribe': 'قبيلة/أسرة', 'nasab': 'نسب', 'geo': 'جغرافيا', 'intro': 'مقدمة/تمهيد'}
PER_PAGE = 20

def db():
    if 'db' not in g:
        g.db = sqlite3.connect(UDB); g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close(_):
    d = g.pop('db', None)
    if d: d.close()

def src_db(name):
    c = sqlite3.connect(os.path.join(BASE, 'data', SOURCES[name][2])); c.row_factory = sqlite3.Row; return c

# ---------- بناء استعلام FTS ----------
def fts_query(q):
    q = norm(q)
    parts = re.findall(r'"([^"]+)"|(\S+)', q)
    exprs = []
    for phrase, tok in parts:
        if phrase:
            exprs.append('"%s"' % re.sub(r'[^\w ]', ' ', phrase).strip())
            continue
        t = re.sub(r'[^\w]', '', tok)
        if not t: continue
        alts = [t + '*']
        if t.startswith('ال') and len(t) > 3: alts.append(t[2:] + '*')
        elif len(t) > 2: alts.append('ال' + t)
        exprs.append('(' + ' OR '.join(alts) + ')')
    return ' AND '.join(exprs)

def snippet(body, q, width=140):
    """مقتطف من النص الأصلي مع إبراز الكلمات (مطابقة على النص المطبّع)."""
    terms = [t for t in re.findall(r'\w+', norm(q)) if t]
    terms = [t[2:] if t.startswith('ال') and len(t) > 3 else t for t in terms]
    nb, idx = norm_with_map(body)
    first = None
    spans = []
    for t in terms:
        for m in re.finditer(re.escape(t), nb):
            spans.append((idx[m.start()], idx[m.end() - 1] + 1))
            if first is None or m.start() < first: first = m.start()
    if first is None:
        return escape(body[:width * 2]) + ('…' if len(body) > width * 2 else '')
    start = max(0, idx[first] - width); end = min(len(body), idx[first] + width * 2)
    spans = sorted(s for s in spans if s[0] >= start and s[1] <= end)
    out, pos = [], start
    for a, b in spans:
        if a < pos: continue
        out += [escape(body[pos:a]), Markup('<mark>'), escape(body[a:b]), Markup('</mark>')]; pos = b
    out.append(escape(body[pos:end]))
    return Markup(('…' if start else '') + ''.join(str(x) for x in out) + ('…' if end < len(body) else ''))

@app.context_processor
def inject():
    return dict(SOURCES=SOURCES, TYPE_LABEL=TYPE_LABEL)

# ---------- الصفحات ----------
@app.route('/')
def home():
    d = db()
    stats = d.execute('select source, count(*) n from docs group by source').fetchall()
    stats = {r['source']: r['n'] for r in stats}
    extra = dict(
        begets=d.execute('select count(*) from begets').fetchone()[0],
        mentions=d.execute('select count(*) from mentions').fetchone()[0],
        links=d.execute('''select count(distinct a.key) from docs a join docs b on a.key=b.key and a.source<b.source
                           where a.key!="" ''').fetchone()[0])
    return render_template('index.html', stats=stats, extra=extra)

@app.route('/search')
def search():
    q = request.args.get('q', '').strip()
    srcs = request.args.getlist('src')
    dtype = request.args.get('type', '')
    page = max(1, int(request.args.get('page', 1) or 1))
    results, facets, total = [], {}, 0
    if q:
        m = fts_query(q)
        if m:
            d = db()
            k = key(q)
            where, args = ['docs_fts match ?'], [m]
            if dtype: where.append('d.doc_type=?'); args.append(dtype)
            base = 'from docs_fts join docs d on d.id=docs_fts.rowid where '
            facets = {r['source']: r['n'] for r in d.execute(
                'select d.source, count(*) n ' + base + ' and '.join(where) + ' group by d.source', args)}
            w2, a2 = list(where), list(args)
            if srcs: w2.append('d.source in (%s)' % ','.join('?' * len(srcs))); a2 += srcs
            total = d.execute('select count(*) ' + base + ' and '.join(w2), a2).fetchone()[0]
            rows = d.execute(
                'select d.*, bm25(docs_fts, 12.0, 1.0) rank ' + base + ' and '.join(w2) +
                ' order by (d.key=?) desc, (d.title_norm=?) desc, rank limit ? offset ?',
                a2 + [k, norm(q), PER_PAGE, (page - 1) * PER_PAGE]).fetchall()
            for r in rows:
                results.append(dict(r=r, snip=snippet(r['body'], q), exact=(r['key'] == k and k != '')))
    pages = (total + PER_PAGE - 1) // PER_PAGE
    return render_template('search.html', q=q, srcs=srcs, dtype=dtype, results=results, facets=facets,
                           total=total, page=page, pages=pages)

def related(doc):
    """سجلات مرتبطة من مصادر أخرى (نفس اسم الموضع) + ذكره في صفة الجزيرة."""
    d = db(); out = {'same': [], 'mentions': []}
    if doc['key']:
        out['same'] = d.execute('select id,source,doc_type,title,subtype,grp,substr(body,1,160) b from docs '
                                'where key=? and id!=? order by source', (doc['key'], doc['id'])).fetchall()
        out['mentions'] = d.execute('select m.*, d.title sec, d.volume, d.page from mentions m join docs d on d.id=m.doc_id '
                                    'where m.key=? order by (m.confidence="high") desc limit 30', (doc['key'],)).fetchall()
    return out

@app.route('/doc/<int:doc_id>')
def doc(doc_id):
    d = db()
    row = d.execute('select * from docs where id=?', (doc_id,)).fetchone()
    if not row: abort(404)
    meta = json.loads(row['meta'] or '{}')
    verses, begets, mentions, neighbors = [], [], [], {}
    if row['source'] in ('hajari', 'iklil', 'sifat') and row['doc_type'] != 'intro':
        c = src_db(row['source'])
        col = 'entry_id' if row['source'] == 'hajari' else 'paragraph_id'
        verses = c.execute(f'select sadr,ajz,intro from verses where {col}=?', (row['ref_id'],)).fetchall()
        c.close()
    if row['source'] == 'iklil':
        begets = d.execute('select * from begets where doc_id=?', (doc_id,)).fetchall()
    if row['source'] == 'sifat':
        mentions = d.execute('select * from mentions where doc_id=?', (doc_id,)).fetchall()
    if row['doc_type'] in ('nasab', 'geo'):
        neighbors['prev'] = d.execute('select id,substr(body,1,60) b from docs where source=? and id<? order by id desc limit 1', (row['source'], doc_id)).fetchone()
        neighbors['next'] = d.execute('select id,substr(body,1,60) b from docs where source=? and id>? order by id limit 1', (row['source'], doc_id)).fetchone()
    return render_template('doc.html', d=row, meta=meta, verses=verses, begets=begets, mentions=mentions,
                           rel=related(row), neighbors=neighbors)

@app.route('/browse')
@app.route('/browse/<source>')
def browse(source=None):
    d = db()
    if not source:
        return render_template('browse.html', source=None, groups=[], docs=[])
    if source not in SOURCES: abort(404)
    grp = request.args.get('grp'); st = request.args.get('sub'); page = max(1, int(request.args.get('page', 1)))
    if grp is None:
        groups = d.execute('select grp, count(*) n, min(id) first from docs where source=? group by grp order by first', (source,)).fetchall()
        subs = d.execute('select subtype, count(*) n from docs where source=? and subtype!="" group by 1 order by 2 desc limit 25', (source,)).fetchall() if source == 'hajari' else []
        if st:
            rows = d.execute('select * from docs where source=? and subtype=? order by id limit ? offset ?', (source, st, PER_PAGE * 3, (page-1)*PER_PAGE*3)).fetchall()
            return render_template('browse.html', source=source, groups=[], docs=rows, subs=subs, grp=None, st=st, page=page, total=None)
        return render_template('browse.html', source=source, groups=groups, docs=[], subs=subs, grp=None, st=None, page=1, total=None)
    total = d.execute('select count(*) from docs where source=? and grp=?', (source, grp)).fetchone()[0]
    rows = d.execute('select * from docs where source=? and grp=? order by id limit ? offset ?', (source, grp, PER_PAGE * 3, (page-1)*PER_PAGE*3)).fetchall()
    return render_template('browse.html', source=source, groups=[], docs=rows, subs=[], grp=grp, st=None, page=page, total=total)

# ---------- الأنساب ----------
def ancestors(name_norm, limit=25):
    d = db(); chain, seen, cur = [], set(), name_norm
    while cur and cur not in seen and len(chain) < limit:
        seen.add(cur)
        r = d.execute('select b.father, b.father_norm from child_items c join begets b on b.id=c.beget_id '
                      'where c.child_norm=? order by b.id limit 1', (cur,)).fetchone()
        if not r: break
        chain.append(r['father']); cur = r['father_norm']
    return chain

def descendants(name_norm, depth=3, seen=None):
    d = db(); seen = seen or set()
    out = []
    for b in d.execute('select * from begets where father_norm=? order by id', (name_norm,)):
        for ch in [c.strip() for c in (b['children'] or '').split('|') if c.strip()]:
            n = norm(ch)
            node = {'name': ch, 'beget': b['id'], 'doc': b['doc_id'], 'kids': []}
            if depth > 1 and n not in seen and n != name_norm:
                seen.add(n); node['kids'] = descendants(n, depth - 1, seen)
            out.append(node)
    return out

@app.route('/nasab')
def nasab():
    q = request.args.get('q', '').strip(); d = db(); res = {}
    if q:
        n = norm(q)
        res['as_father'] = d.execute('select * from begets where father_norm=? or father_norm like ? order by (father_norm=?) desc, id limit 40', (n, n + ' %', n)).fetchall()
        res['as_child'] = d.execute('select b.*, c.child from child_items c join begets b on b.id=c.beget_id where c.child_norm=? or c.child_norm like ? limit 40', (n, n + ' %')).fetchall()
    sections = d.execute('select grp, min(id) first, count(*) n from docs where source="iklil" group by grp order by first').fetchall() if not q else []
    return render_template('nasab.html', q=q, res=res, sections=sections)

@app.route('/person')
def person():
    name = request.args.get('name', '').strip(); n = norm(name); d = db()
    if not n: abort(404)
    depth = min(4, max(1, int(request.args.get('depth', 3))))
    fathers = d.execute('select * from begets where father_norm=? order by id', (n,)).fetchall()
    parents = d.execute('select b.*, c.child from child_items c join begets b on b.id=c.beget_id where c.child_norm=? order by b.id', (n,)).fetchall()
    desc = descendants(n, depth)
    anc = ancestors(n)
    # سجلات القبائل/المواضع بنفس الاسم في المصادر الأخرى
    k = key(name)
    places = d.execute('select id,source,doc_type,title,subtype,substr(body,1,140) b from docs where key=? limit 12', (k,)).fetchall() if k else []
    return render_template('person.html', name=name, fathers=fathers, parents=parents, desc=desc, anc=anc, depth=depth, places=places)

@app.route('/sources')
def sources():
    d = db(); info = []
    for key_, (title, author, fn) in SOURCES.items():
        c = src_db(key_)
        tabs = []
        for (t,) in c.execute("select name from sqlite_master where type='table' and name not like '%\\_fts%' escape '\\' order by name"):
            cols = [r[1] for r in c.execute(f'pragma table_info("{t}")')]
            tabs.append((t, c.execute(f'select count(*) from "{t}"').fetchone()[0], cols))
        c.close(); info.append((key_, title, author, fn, tabs))
    return render_template('sources.html', info=info)

@app.route('/api/suggest')
def suggest():
    q = norm(request.args.get('q', ''))
    if len(q) < 2: return jsonify([])
    rows = db().execute('select distinct title from docs where title_norm like ? and doc_type in ("place","tribe") order by length(title) limit 10', (q + '%',)).fetchall()
    return jsonify([r['title'] for r in rows])

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)
