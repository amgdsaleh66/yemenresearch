import re
_TASHKEEL = re.compile(r'[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u0640]')
_MAP = str.maketrans({'أ':'ا','إ':'ا','آ':'ا','ٱ':'ا','ى':'ي','ة':'ه','ؤ':'و','ئ':'ي','ک':'ك','ی':'ي'})

def norm(s):
    """تطبيع عربي: حذف التشكيل والتطويل، توحيد الألف والياء والتاء المربوطة."""
    if not s: return ''
    s = _TASHKEEL.sub('', s).translate(_MAP)
    return re.sub(r'\s+', ' ', s).strip()

def key(s):
    """مفتاح الربط بين المصادر: مطبّع + بدون «ال» التعريف الأولى."""
    n = norm(s)
    return n[2:] if n.startswith('ال') and len(n) > 3 else n

def norm_with_map(s):
    """يعيد (نص مطبّع, خريطة من موضع المطبّع إلى موضع الأصل) لتمييز النتائج على النص الأصلي."""
    out, idx = [], []
    for i, ch in enumerate(s):
        if _TASHKEEL.match(ch): continue
        out.append(ch.translate(_MAP)); idx.append(i)
    return ''.join(out), idx
