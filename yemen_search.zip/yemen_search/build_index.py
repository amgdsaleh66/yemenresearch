"""يبني قاعدة موحدة data/unified.db من القواعد الأربع: فهرس بحث FTS5 + جداول ربط."""
import sqlite3, os, json, sys
from arabic import norm, key

D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data')
OUT = os.path.join(D, 'unified.db')

SOURCES = {
 'mucjam':  ('معجم البلدان',        'ياقوت الحموي',        'mucjam_buldan.db'),
 'hajari':  ('مجموع بلدان اليمن وقبائلها', 'محمد بن أحمد الحجري', 'hajari_buldan_yaman.db'),
 'iklil':   ('الإكليل (الأنساب)',   'الهمداني',            'iklil.db'),
 'sifat':   ('صفة جزيرة العرب',     'الهمداني',            'sifat_jazirat_alarab.db'),
}

def ro(name): 
    c = sqlite3.connect(os.path.join(D, SOURCES[name][2])); c.row_factory = sqlite3.Row; return c

def build():
    if os.path.exists(OUT): os.remove(OUT)
    u = sqlite3.connect(OUT)
    u.executescript('''
    CREATE TABLE docs(id INTEGER PRIMARY KEY, source TEXT, doc_type TEXT, subtype TEXT, title TEXT, title_norm TEXT,
        key TEXT, grp TEXT, body TEXT, volume INTEGER, page INTEGER, ref_id INTEGER, meta TEXT);
    CREATE INDEX i_docs_key ON docs(key); CREATE INDEX i_docs_src ON docs(source,grp);
    CREATE VIRTUAL TABLE docs_fts USING fts5(title_norm, body_norm, tokenize="unicode61 remove_diacritics 0");
    CREATE TABLE begets(id INTEGER PRIMARY KEY, doc_id INTEGER, section TEXT, verb TEXT, father TEXT, father_norm TEXT,
        children TEXT, n_children INTEGER, raw TEXT);
    CREATE TABLE child_items(beget_id INTEGER, child TEXT, child_norm TEXT);
    CREATE INDEX i_ci ON child_items(child_norm); CREATE INDEX i_bf ON begets(father_norm);
    CREATE TABLE mentions(id INTEGER PRIMARY KEY, doc_id INTEGER, place_name TEXT, key TEXT, place_type TEXT, confidence TEXT, context TEXT);
    CREATE INDEX i_m_key ON mentions(key);
    ''')
    rows = []   # (source, doc_type, subtype, title, grp, body, vol, page, ref_id, meta)

    # --- معجم البلدان
    c = ro('mucjam')
    for r in c.execute('select id,place_name,section,content from places'):
        rows.append(('mucjam','place','',r['place_name'],r['section'] or '',r['content'],None,None,r['id'],{}))
    for r in c.execute('select id,title,content from other_sections'):
        rows.append(('mucjam','intro','',r['title'],'المقدمة والأبواب التمهيدية',r['content'],None,None,r['id'],{'table':'other_sections'}))

    # --- الحجري
    c = ro('hajari')
    letters = {r['id']: r['title'] for r in c.execute('select id,title from letters')}
    for r in c.execute('select * from entries'):
        grp = r['province'] or letters.get(r['letter_id'], '')
        rows.append(('hajari', 'tribe' if r['entry_kind']=='tribe' else 'place', r['place_type'] or '',
                     r['name'], letters.get(r['letter_id'],''), r['content'], r['volume'], r['page'], r['id'],
                     {'admin_chain': r['admin_chain'], 'province': r['province'], 'first': r['first_sentence']}))
    for r in c.execute('select id,title,content from other_sections'):
        rows.append(('hajari','intro','',r['title'],'مقدمات',r['content'],None,None,r['id'],{'table':'other_sections'}))

    # --- الإكليل وصفة الجزيرة (فقرات)
    para_doc = {}
    for src, dt in (('iklil','nasab'), ('sifat','geo')):
        c = ro(src)
        secs = {r['id']: r['title'] for r in c.execute('select id,title from sections')}
        for r in c.execute('select * from paragraphs'):
            rows.append((src, dt, r['kind'], secs.get(r['section_id'],''), secs.get(r['section_id'],''),
                         r['text'], r['volume'], r['page'], r['id'], {'section_id': r['section_id']}))

    doc_ids = {}
    for i, (src, dt, st, title, grp, body, vol, page, ref, meta) in enumerate(rows, 1):
        u.execute('insert into docs values(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                  (i, src, dt, st, title, norm(title), key(title) if dt in ('place','tribe') else '',
                   grp, body, vol, page, ref, json.dumps(meta, ensure_ascii=False)))
        u.execute('insert into docs_fts(rowid,title_norm,body_norm) values(?,?,?)', (i, norm(title), norm(body)))
        doc_ids[(src, dt in ('nasab','geo'), ref)] = i

    # --- الأنساب (أولد/ولد)
    c = ro('iklil')
    secs = {r['id']: r['title'] for r in c.execute('select id,title from sections')}
    for r in c.execute('select * from begets'):
        did = doc_ids.get(('iklil', True, r['paragraph_id']))
        u.execute('insert into begets values(?,?,?,?,?,?,?,?,?)',
                  (r['id'], did, secs.get(r['section_id'],''), r['verb'], r['father'], norm(r['father']),
                   r['children'], r['n_children'], r['raw']))
        for ch in (r['children'] or '').split('|'):
            ch = ch.strip()
            if ch: u.execute('insert into child_items values(?,?,?)', (r['id'], ch, norm(ch)))

    # --- ذكر المواضع في صفة الجزيرة
    c = ro('sifat')
    for r in c.execute('select * from place_mentions'):
        did = doc_ids.get(('sifat', True, r['paragraph_id']))
        u.execute('insert into mentions(doc_id,place_name,key,place_type,confidence,context) values(?,?,?,?,?,?)',
                  (did, r['place_name'], key(r['place_name']), r['place_type'], r['confidence'], r['context']))
    u.commit()
    n = u.execute('select count(*) from docs').fetchone()[0]
    u.execute("insert into docs_fts(docs_fts) values('optimize')"); u.commit(); u.close()
    print('docs indexed:', n)

if __name__ == '__main__':
    build()
